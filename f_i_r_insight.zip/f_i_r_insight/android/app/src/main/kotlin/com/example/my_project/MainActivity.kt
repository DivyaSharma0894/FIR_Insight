package com.mycompany.firinsight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
